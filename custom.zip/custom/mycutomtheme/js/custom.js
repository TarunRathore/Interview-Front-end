/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */ 
jQuery( document ).ready(function() {
jQuery('.footer-links-pages li:eq(0)').removeClass( "sub-links" );
jQuery('.footer-links-pages li:eq(1)').removeClass( "sub-links" );
jQuery('.footer-links-pages li:eq(1)').append('<br>'); 
});

jQuery('ul.nav li.dropdown').hover(function() {
  jQuery(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
}, function() {
  jQuery(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
});



